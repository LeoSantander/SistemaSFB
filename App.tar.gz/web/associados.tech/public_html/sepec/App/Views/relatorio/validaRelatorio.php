<div class="container">
  <table width="100%">
    <tr>
      <td align="center">
      <div class="card w-50">
        <div class="card-header">
          <h3>Aviso</h3>
        </div>
        <div class="card-body">
            <?php echo $Sessao::retornaMensagem(); ?>
        </div>
        <div class="card-footer">
          <table width="100%"><tr><td align="right"><a href="javascript:window.close()" class="btn btn-primary">Voltar</a></td></tr></table>

        </div>
      </div>
    </td>
    </tr>
  </table>
</div>
